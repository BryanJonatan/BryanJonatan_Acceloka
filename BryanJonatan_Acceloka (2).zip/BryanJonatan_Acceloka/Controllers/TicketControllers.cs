﻿using BryanJonatan_Acceloka.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BryanJonatan_Acceloka.Controllers
{
    public class TicketControllers
    {
        [ApiController]
        [Route("api/v1")]
        public class TicketsController : ControllerBase
        {
            private readonly AppDbContext _context;

            public TicketsController(AppDbContext context)
            {
                _context = context;
            }

            [HttpGet("get-available-ticket")]
            public async Task<IActionResult> GetAvailableTickets(string? categoryName, string? ticketCode, string? ticketName, decimal? price, DateTime? minEventDate, DateTime? maxEventDate, string? orderBy = "TicketCode", string? orderState = "asc", int pageNumber = 1, int pageSize = 10)
            {
                var query = _context.Tickets.AsQueryable();

                if (!string.IsNullOrEmpty(categoryName))
                {
                    query = query.Where(t => t.CategoryName.Contains(categoryName));
                }
                if (!string.IsNullOrEmpty(ticketCode))
                {
                    query = query.Where(t => t.TicketCode.Contains(ticketCode));
                }
                if (!string.IsNullOrEmpty(ticketName))
                {
                    query = query.Where(t => t.TicketName.Contains(ticketName));
                }
                if (price.HasValue)
                {
                    query = query.Where(t => t.Price <= price.Value);
                }
                if (minEventDate.HasValue)
                {
                    query = query.Where(t => t.EventDate >= minEventDate.Value);
                }
                if (maxEventDate.HasValue)
                {
                    query = query.Where(t => t.EventDate <= maxEventDate.Value);
                }

                query = orderState.ToLower() == "desc" ? query.OrderByDescending(t => EF.Property<object>(t, orderBy)) : query.OrderBy(t => EF.Property<object>(t, orderBy));

                var totalRecords = await query.CountAsync();
                var tickets = await query.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToListAsync();

                return Ok(new
                {
                    TotalRecords = totalRecords,
                    PageNumber = pageNumber,
                    PageSize = pageSize,
                    Data = tickets
                });
            }

            [HttpPost("book-ticket")]
            public async Task<IActionResult> BookTicket([FromBody] List<BookedTicket> bookedTickets)
            {
                await _context.BookedTickets.AddRangeAsync(bookedTickets);
                await _context.SaveChangesAsync();
                return Ok(bookedTickets);
            }

            [HttpGet("get-booked-ticket/{bookedTicketId}")]
            public async Task<IActionResult> GetBookedTicket(int bookedTicketId)
            {
                var bookedTicket = await _context.BookedTickets.FindAsync(bookedTicketId);
                if (bookedTicket == null)
                {
                    return NotFound();
                }
                return Ok(bookedTicket);
            }

            [HttpDelete("revoke-ticket/{bookedTicketId}/{ticketCode}/{qty}")]
            public async Task<IActionResult> RevokeTicket(int bookedTicketId, string ticketCode, int qty)
            {
                var bookedTicket = await _context.BookedTickets.FindAsync(bookedTicketId);
                if (bookedTicket == null) return NotFound();

                bookedTicket.Quantity -= qty;
                if (bookedTicket.Quantity <= 0)
                {
                    _context.BookedTickets.Remove(bookedTicket);
                }
                await _context.SaveChangesAsync();
                return Ok(bookedTicket);
            }

            [HttpPut("edit-booked-ticket/{bookedTicketId}")]
            public async Task<IActionResult> EditBookedTicket(int bookedTicketId, [FromBody] List<BookedTicket> updatedTickets)
            {
                var bookedTicket = await _context.BookedTickets.FindAsync(bookedTicketId);
                if (bookedTicket == null) return NotFound();

                foreach (var updated in updatedTickets)
                {
                    bookedTicket.Quantity = updated.Quantity;
                }
                await _context.SaveChangesAsync();
                return Ok(bookedTicket);
            }
        }


    }
}
