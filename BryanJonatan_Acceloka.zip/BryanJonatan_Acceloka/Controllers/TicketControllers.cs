﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BryanJonatan_Acceloka.Model;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Net;

namespace BryanJonatan_Acceloka.Controllers
{
    [ApiController]
    [Route("api/v1")]
    public class TicketsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TicketsController(AppDbContext context)
        {
            _context = context;
        }

    

        [HttpGet("get-available-ticket")]
        public async Task<IActionResult> GetAvailableTickets(
      string? categoryName, string? ticketCode, string? ticketName, decimal? price,
      DateTime? minEventDate, DateTime? maxEventDate, string? orderBy = "TicketCode",
      string? orderState = "asc", int pageNumber = 1, int pageSize = 10)
        {
            // Validate orderBy and orderState
            var validColumns = new[] { "TicketCode", "TicketName", "CategoryName", "Price", "EventDate" };
            if (!validColumns.Contains(orderBy))
            {
                return BadRequest(new ProblemDetails
                {
                    Type = "https://tools.ietf.org/html/rfc7807",
                    Title = "Invalid OrderBy",
                    Status = (int)HttpStatusCode.BadRequest,
                    Detail = $"OrderBy must be one of: {string.Join(", ", validColumns)}."
                });
            }

            if (orderState.ToLower() != "asc" && orderState.ToLower() != "desc")
            {
                return BadRequest(new ProblemDetails
                {
                    Type = "https://tools.ietf.org/html/rfc7807",
                    Title = "Invalid OrderState",
                    Status = (int)HttpStatusCode.BadRequest,
                    Detail = "OrderState must be 'asc' or 'desc'."
                });
            }

            var query = _context.Tickets.AsQueryable();

            // Apply filters
            if (!string.IsNullOrEmpty(categoryName))
                query = query.Where(t => t.CategoryName.Contains(categoryName));
            if (!string.IsNullOrEmpty(ticketCode))
                query = query.Where(t => t.TicketCode.Contains(ticketCode));
            if (!string.IsNullOrEmpty(ticketName))
                query = query.Where(t => t.TicketName.Contains(ticketName));
            if (price.HasValue)
                query = query.Where(t => t.Price <= price.Value);
            if (minEventDate.HasValue)
                query = query.Where(t => t.EventDate >= minEventDate.Value);
            if (maxEventDate.HasValue)
                query = query.Where(t => t.EventDate <= maxEventDate.Value);

            // Apply ordering
            query = orderState.ToLower() == "desc"
                ? query.OrderByDescending(t => EF.Property<object>(t, orderBy))
                : query.OrderBy(t => EF.Property<object>(t, orderBy));

            // Pagination
            var totalRecords = await query.CountAsync();
            var tickets = await query.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToListAsync();

            // Calculate Sisa Quota for each ticket and filter out those with no available quota
            var availableTickets = tickets.Select(t => new
            {
                NamaKategori = t.CategoryName,
                KodeTiket = t.TicketCode,
                NamaTiket = t.TicketName,
                TanggalEvent = t.EventDate,
                Harga = t.Price,
                // Calculate remaining quota and exclude tickets with no available quota
                SisaQuota = t.Quota - (_context.BookedTickets
                    .Where(bt => bt.TicketId == t.TicketCode) // Match using TicketCode if TicketId is a string
                    .Sum(bt => (int?)bt.Quantity) ?? 0)
            }).Where(t => t.SisaQuota > 0).ToList(); // Only return tickets with remaining quota

            return Ok(new
            {
                TotalRecords = totalRecords,
                PageNumber = pageNumber,
                PageSize = pageSize,
                Data = availableTickets
            });
        }


        [HttpPost("book-ticket")]
        public async Task<IActionResult> BookTicket([FromBody] List<BookTicketRequest> bookingRequests)
        {
            var response = new List<BookTicketResponse>();
            var categoryTotals = new Dictionary<string, decimal>();
            decimal totalPriceAllCategories = 0;

            foreach (var request in bookingRequests)
            {
                var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.TicketCode == request.TicketCode);
                if (ticket == null)
                {
                    return NotFound(new ProblemDetails
                    {
                        Type = "https://tools.ietf.org/html/rfc7807",
                        Title = "Ticket Not Found",
                        Status = (int)HttpStatusCode.NotFound,
                        Detail = $"Ticket with code {request.TicketCode} does not exist."
                    });
                }

                var totalBookedQuantity = await _context.BookedTickets
                    .Where(bt => bt.TicketCode == request.TicketCode)
                    .SumAsync(bt => bt.Quantity);

                if (request.Quantity > (ticket.Quota - totalBookedQuantity))
                {
                    return BadRequest(new ProblemDetails
                    {
                        Type = "https://tools.ietf.org/html/rfc7807",
                        Title = "Insufficient Quota",
                        Status = (int)HttpStatusCode.BadRequest,
                        Detail = $"The requested quantity exceeds the available quota for ticket {request.TicketCode}."
                    });
                }

                if (ticket.EventDate <= DateTime.Now)
                {
                    return BadRequest(new ProblemDetails
                    {
                        Type = "https://tools.ietf.org/html/rfc7807",
                        Title = "Invalid Event Date",
                        Status = (int)HttpStatusCode.BadRequest,
                        Detail = $"The event date for ticket {request.TicketCode} has already passed."
                    });
                }

                var bookedTicket = new BookedTicket
                {
                    TicketCode = request.TicketCode,
                    Quantity = request.Quantity
                };

                await _context.BookedTickets.AddAsync(bookedTicket);
                await _context.SaveChangesAsync();

                decimal ticketTotalPrice = request.Quantity * ticket.Price;

                response.Add(new BookTicketResponse
                {
                    NamaTicket = ticket.TicketName,
                    KodeTicket = ticket.TicketCode,
                    Harga = ticket.Price,
                    Quantity = request.Quantity,
                    TotalHarga = ticketTotalPrice
                });

                if (categoryTotals.ContainsKey(ticket.CategoryName))
                {
                    categoryTotals[ticket.CategoryName] += ticketTotalPrice;
                }
                else
                {
                    categoryTotals[ticket.CategoryName] = ticketTotalPrice;
                }

                totalPriceAllCategories += ticketTotalPrice;
            }

            var summary = new
            {
                TotalHargaPerKategori = categoryTotals,
                TotalHargaSemuaKategori = totalPriceAllCategories
            };

            return Ok(new { Data = response, Summary = summary });
        }

        [HttpGet("get-booked-ticket/{bookedTicketId}")]
        public async Task<IActionResult> GetBookedTicket(string bookedTicketId)
        {
            var bookedTicket = await _context.BookedTickets
                .Include(bt => bt.Tickets)
                .FirstOrDefaultAsync(bt => bt.TicketId == bookedTicketId);

            if (bookedTicket == null)
            {
                return NotFound(new ProblemDetails
                {
                    Type = "https://tools.ietf.org/html/rfc7807",
                    Title = "Booked Ticket Not Found",
                    Status = (int)HttpStatusCode.NotFound,
                    Detail = $"Booked Ticket with ID {bookedTicketId} does not exist."
                });
            }

            var response = new
            {
                KodeTiket = bookedTicket.TicketCode,
                NamaTiket = bookedTicket.Tickets.TicketName,
                TanggalEvent = bookedTicket.Tickets.EventDate,
                Quantity = bookedTicket.Quantity,
                Kategori = bookedTicket.Tickets.CategoryName
            };

            return Ok(response);
        }

        [HttpDelete("revoke-ticket/{bookedTicketId}/{ticketCode}/{qty}")]
        public async Task<IActionResult> RevokeTicket(string bookedTicketId, string ticketCode, int qty)
        {
            var bookedTicket = await _context.BookedTickets
                .Include(bt => bt.Tickets)
                .FirstOrDefaultAsync(bt => bt.TicketId == bookedTicketId && bt.TicketCode == ticketCode);

            if (bookedTicket == null)
            {
                return NotFound(new ProblemDetails
                {
                    Type = "https://tools.ietf.org/html/rfc7807",
                    Title = "Booked Ticket Not Found",
                    Status = (int)HttpStatusCode.NotFound,
                    Detail = $"Booked Ticket with ID {bookedTicketId} and Ticket Code {ticketCode} does not exist."
                });
            }

            if (qty > bookedTicket.Quantity)
            {
                return BadRequest(new ProblemDetails
                {
                    Type = "https://tools.ietf.org/html/rfc7807",
                    Title = "Invalid Quantity",
                    Status = (int)HttpStatusCode.BadRequest,
                    Detail = $"The requested quantity exceeds the booked quantity for ticket {ticketCode}."
                });
            }

            bookedTicket.Quantity -= qty;
            if (bookedTicket.Quantity <= 0)
            {
                _context.BookedTickets.Remove(bookedTicket);
            }

            await _context.SaveChangesAsync();

            var response = new
            {
                KodeTicket = bookedTicket.TicketCode,
                NamaTicket = bookedTicket.Tickets.TicketName,
                NamaKategori = bookedTicket.Tickets.CategoryName,
                SisaQuantity = bookedTicket.Quantity
            };

            return Ok(response);
        }

        [HttpPut("edit-booked-ticket/{bookedTicketId}")]
        public async Task<IActionResult> EditBookedTicket(string bookedTicketId, [FromBody] List<BookedTicketUpdateRequest> updates)
        {
            var bookedTicket = await _context.BookedTickets
                .Include(bt => bt.Tickets)
                .FirstOrDefaultAsync(bt => bt.TicketId == bookedTicketId);

            if (bookedTicket == null)
            {
                return NotFound(new ProblemDetails
                {
                    Type = "https://tools.ietf.org/html/rfc7807",
                    Title = "Booked Ticket Not Found",
                    Status = (int)HttpStatusCode.NotFound,
                    Detail = $"Booked Ticket with ID {bookedTicketId} does not exist."
                });
            }

            foreach (var update in updates)
            {
                var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.TicketCode == update.TicketCode);
                if (ticket == null)
                {
                    return NotFound(new ProblemDetails
                    {
                        Type = "https://tools.ietf.org/html/rfc7807",
                        Title = "Ticket Not Found",
                        Status = (int)HttpStatusCode.NotFound,
                        Detail = $"Ticket with code {update.TicketCode} does not exist."
                    });
                }

                if (update.Quantity < 1)
                {
                    return BadRequest(new ProblemDetails
                    {
                        Type = "https://tools.ietf.org/html/rfc7807",
                        Title = "Invalid Quantity",
                        Status = (int)HttpStatusCode.BadRequest,
                        Detail = "Quantity must be at least 1."
                    });
                }

                var totalBookedQuantity = await _context.BookedTickets
                    .Where(bt => bt.TicketCode == update.TicketCode)
                    .SumAsync(bt => bt.Quantity);

                if (update.Quantity > (ticket.Quota - totalBookedQuantity + bookedTicket.Quantity))
                {
                    return BadRequest(new ProblemDetails
                    {
                        Type = "https://tools.ietf.org/html/rfc7807",
                        Title = "Insufficient Quota",
                        Status = (int)HttpStatusCode.BadRequest,
                        Detail = $"The requested quantity exceeds the available quota for ticket {update.TicketCode}."
                    });
                }

                bookedTicket.Quantity = update.Quantity;
            }

            await _context.SaveChangesAsync();

            var response = new
            {
                KodeTicket = bookedTicket.TicketCode,
                NamaTicket = bookedTicket.Tickets.TicketName,
                NamaKategori = bookedTicket.Tickets.CategoryName,
                SisaQuantity = bookedTicket.Tickets.Quota - await _context.BookedTickets
                    .Where(bt => bt.TicketCode == bookedTicket.TicketCode)
                    .SumAsync(bt => bt.Quantity)
            };

            return Ok(response);
        }
    }
}