﻿namespace BryanJonatan_Acceloka.Model
{
    public class Ticket
    {

    public string TicketCode { get; set; } // Unique Identifier (used as TicketId reference in BookedTicket)
    public string CategoryName { get; set; }
    public string TicketName { get; set; }
    public DateTime EventDate { get; set; }
    public decimal Price { get; set; }
    public int Quota { get; set; }
       

    }
}
