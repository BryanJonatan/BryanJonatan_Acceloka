﻿namespace BryanJonatan_Acceloka.Model
{
    public class Ticket
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public string TicketCode { get; set; }
        public string TicketName { get; set; }
        public DateTime EventDate { get; set; }
        public decimal Price { get; set; }
        public int Quota { get; set; }
    }
}
