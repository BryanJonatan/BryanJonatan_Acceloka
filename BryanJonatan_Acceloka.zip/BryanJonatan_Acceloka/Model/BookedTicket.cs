﻿namespace BryanJonatan_Acceloka.Model
{
    public class BookedTicket
    {
        public String TicketId { get; set; }
        public string TicketCode { get; set; }
        public int Quantity { get; set; }
        public DateTime BookingDate { get; set; }
        public Ticket Tickets { get; set; }


    }
}
