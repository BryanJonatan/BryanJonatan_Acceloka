﻿namespace BryanJonatan_Acceloka.Model
{
    public class BookedTicket
    {
        public int Id { get; set; }
        public int TicketId { get; set; }
        public int Quantity { get; set; }
        public DateTime BookingDate { get; set; }
    }
}
