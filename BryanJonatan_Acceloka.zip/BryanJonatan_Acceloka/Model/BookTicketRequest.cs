﻿namespace BryanJonatan_Acceloka.Model
{
    public class BookTicketRequest
    {
        public required string TicketCode { get; set; }
        public int Quantity { get; set; }

    }
}

