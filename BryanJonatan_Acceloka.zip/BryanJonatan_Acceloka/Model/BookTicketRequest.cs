﻿namespace BryanJonatan_Acceloka.Model
{
    public class BookTicketRequest
    {
            public string TicketCode { get; set; } // Ticket code to book
            public int Quantity { get; set; } // Quantity to book
        
    }
}

