﻿namespace BryanJonatan_Acceloka.Model
{
    public class BookTicketResponse
    {
        public string NamaTicket { get; set; } // Ticket name
        public string KodeTicket { get; set; } // Ticket code
        public decimal Harga { get; set; } // Ticket price
        public int Quantity { get; set; } // Booked quantity
        public decimal TotalHarga { get; set; } // Total price for this ticket
    }
}
